import tkinter as tk
from tkinter import messagebox
import sqlite3

conn = sqlite3.connect('people.db')
c = conn.cursor()

c.execute('''
    CREATE TABLE IF NOT EXISTS people (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        age INTEGER NOT NULL
    )
''')
conn.commit()


def add_person():
    name = entry_name.get()
    age = entry_age.get()

    if not name or not age:
        messagebox.showwarning("Input Error", "Please fill in both fields")
        return

    try:
        age_int = int(age)
    except ValueError:
        messagebox.showwarning("Input Error", "Age must be a number")
        return

    c.execute("INSERT INTO people (name, age) VALUES (?, ?)", (name, age_int))
    conn.commit()
    entry_name.delete(0, tk.END)
    entry_age.delete(0, tk.END)
    load_people()

def load_people():
    listbox_people.delete(0, tk.END)
    c.execute("SELECT id, name, age FROM people")
    for row in c.fetchall():
        listbox_people.insert(tk.END, f"{row[0]}: {row[1]} ({row[2]} years)")

def delete_person():
    selected = listbox_people.curselection()
    if not selected:
        messagebox.showwarning("Selection Error", "Please select a record to delete")
        return
    person = listbox_people.get(selected[0])
    person_id = int(person.split(":")[0])

    c.execute("DELETE FROM people WHERE id=?", (person_id,))
    conn.commit()
    load_people()


root = tk.Tk()
root.title("Simple Database GUI")


tk.Label(root, text="Name:").grid(row=0, column=0, padx=5, pady=5, sticky='e')
entry_name = tk.Entry(root)
entry_name.grid(row=0, column=1, padx=5, pady=5)


tk.Label(root, text="Age:").grid(row=1, column=0, padx=5, pady=5, sticky='e')
entry_age = tk.Entry(root)
entry_age.grid(row=1, column=1, padx=5, pady=5)


btn_add = tk.Button(root, text="Add Person", command=add_person)
btn_add.grid(row=2, column=0, columnspan=2, pady=10)


listbox_people = tk.Listbox(root, width=40)
listbox_people.grid(row=3, column=0, columnspan=2, padx=5, pady=5)

btn_delete = tk.Button(root, text="Delete Selected", command=delete_person)
btn_delete.grid(row=4, column=0, columnspan=2, pady=10)


load_people()

root.mainloop()

conn.close()
