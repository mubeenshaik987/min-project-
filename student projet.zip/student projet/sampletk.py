import tkinter as tk


root=tk.Tk()
root.geometry('2000x900')
root.title("my application")
root.config(bg='light blue')

m1=tk.Label(root,text="placement registration ",font=("alerian", 30 ,"bold"))
m1.place(x=500,y=50)
m2=tk.Label(root,text="login page",font=("algerian", 16))
m2.place(x=700,y=100)

m3=tk.Label(root,text="email",font=("algerian", 16),bg='light blue')
m3.place(x=500,y=150)

e1=tk.Entry(root,font=("arial", 16))
e1.place(x=700,y=150)

m4=tk.Label(root,text="student name",font=("algerian", 16),bg='light blue')
m4.place(x=500,y=200)

e2=tk.Entry(root,font=("arial", 16))
e2.place(x=700,y=200)

m5=tk.Label(root,text="student id",font=("algerian", 16),bg='light blue')
m5.place(x=500,y=250)

e3=tk.Entry(root,font=("arial", 16))
e3.place(x=700,y=250)

m6=tk.Label(root,text="college name",font=("algerian", 16),bg='light blue')
m6.place(x=500,y=300)

e4=tk.Entry(root,font=("arial", 16))
e4.place(x=700,y=300)

m7=tk.Label(root,text="cgpa",font=("algerian", 16),bg='light blue')
m7.place(x=500,y=350)

e5=tk.Entry(root,font=("arial", 16))
e5.place(x=700,y=350)
 
b1=tk.Button(root,text="submit",font=("italic", 16))
b1.place(x=600,y=400)
b2=tk.Button(root,text="cancle",font=("italic", 16))
b2.place(x=700,y=400)

root.mainloop()